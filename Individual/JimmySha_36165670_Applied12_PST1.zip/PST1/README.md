Music School Management System -PST1 Individual task for FIT1056   
MSMS.py contains an application prototype where all data is stored in  
How to run:  
1. Run the application
2. Use the menu to:
   1. Register new student  
	2. Enrol existing student
   3. Look up a student or teacher by name or specialty
   4. List all
   5. Quit application
